"""Portable Zotero Desktop client and reading-queue helpers.

This module intentionally uses only the Python standard library.  It talks to
Zotero Desktop's local HTTP API and Connector server on localhost; it does not
inspect Zotero's SQLite database and does not depend on a graphical window.
"""

from __future__ import annotations

import configparser
import json
import os
import platform
import re
import shutil
import subprocess
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterator


DEFAULT_BASE_URL = os.environ.get("ZOTERO_LOCAL_BASE_URL", "http://127.0.0.1:23119")
LOCAL_USER = "/api/users/0"
API_VERSION_HEADERS = {"Zotero-API-Version": "3"}
CONNECTOR_HEADERS = {"X-Zotero-Connector-API-Version": "3"}
API_PAGE_LIMIT = 100
TEXT_LIMIT = 500
STYLE_FIELDS = ("sciif", "sci", "sciUp", "sciUpSmall", "eii")


class ZoteroError(RuntimeError):
    """A structured, user-facing Zotero integration error."""


@dataclass(frozen=True)
class Response:
    status: int | None
    headers: dict[str, str]
    text: str
    error: str | None = None

    @property
    def ok(self) -> bool:
        return self.status is not None and 200 <= self.status < 300

    @property
    def content_type(self) -> str:
        for key, value in self.headers.items():
            if key.lower() == "content-type":
                return value
        return ""


def now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def local_timestamp() -> str:
    return time.strftime("%Y%m%d_%H%M%S", time.localtime())


def normalize_name(value: str | None) -> str:
    return re.sub(r"\s+", " ", (value or "").strip()).casefold()


def quote_key(value: str) -> str:
    return urllib.parse.quote(str(value), safe="")


def query(params: dict[str, Any]) -> str:
    clean = {key: value for key, value in params.items() if value is not None}
    return urllib.parse.urlencode(clean)


def creator_names(data: dict[str, Any]) -> list[str]:
    result: list[str] = []
    for creator in data.get("creators", []) or []:
        if not isinstance(creator, dict):
            continue
        name = creator.get("name") or " ".join(
            part
            for part in (creator.get("firstName"), creator.get("lastName"))
            if part
        )
        if name:
            result.append(str(name))
    return result


def year_from_date(value: Any) -> str | None:
    match = re.search(r"(\d{4})", str(value or ""))
    return match.group(1) if match else None


def item_data(item: dict[str, Any]) -> dict[str, Any]:
    data = item.get("data")
    return data if isinstance(data, dict) else item


def summarize_item(item: dict[str, Any]) -> dict[str, Any]:
    data = item_data(item)
    return {
        "key": item.get("key") or data.get("key"),
        "itemType": data.get("itemType"),
        "title": data.get("title"),
        "creators": creator_names(data),
        "year": year_from_date(data.get("date")),
        "date": data.get("date"),
        "dateAdded": data.get("dateAdded"),
        "publicationTitle": data.get("publicationTitle"),
        "DOI": data.get("DOI") or data.get("doi"),
        "abstractNote": data.get("abstractNote"),
    }


def summarize_collection(collection: dict[str, Any]) -> dict[str, Any]:
    data = collection.get("data")
    data = data if isinstance(data, dict) else collection
    return {
        "key": collection.get("key") or data.get("key"),
        "name": data.get("name"),
        "parentCollection": data.get("parentCollection"),
        "version": collection.get("version"),
    }


def summarize_tag(tag: dict[str, Any]) -> dict[str, Any]:
    return {
        "tag": tag.get("tag"),
        "numItems": (tag.get("meta") or {}).get("numItems"),
    }


def summarize_group(group: dict[str, Any]) -> dict[str, Any]:
    data = group.get("data")
    data = data if isinstance(data, dict) else group
    return {
        "id": group.get("id") or data.get("id"),
        "name": data.get("name"),
        "type": data.get("type"),
    }


class ZoteroClient:
    """Small, dependency-free client for Zotero Desktop's local surfaces."""

    def __init__(self, base_url: str | None = None, timeout: float = 8.0):
        self.base_url = (base_url or DEFAULT_BASE_URL).rstrip("/")
        self.timeout = timeout
        # The local server must never be sent through a corporate/system proxy.
        self.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))

    def url_for(self, path: str) -> str:
        if not path.startswith("/"):
            path = "/" + path
        return self.base_url + path

    def request(
        self,
        path: str,
        *,
        method: str = "GET",
        data: Any = None,
        headers: dict[str, str] | None = None,
        timeout: float | None = None,
    ) -> Response:
        request_headers = dict(headers or {})
        if path.startswith("/api"):
            for key, value in API_VERSION_HEADERS.items():
                request_headers.setdefault(key, value)
        if path.startswith("/connector"):
            for key, value in CONNECTOR_HEADERS.items():
                request_headers.setdefault(key, value)

        body: bytes | None = None
        if data is not None:
            if isinstance(data, (dict, list)):
                body = json.dumps(data, ensure_ascii=False).encode("utf-8")
                request_headers.setdefault("Content-Type", "application/json")
            elif isinstance(data, bytes):
                body = data
            else:
                body = str(data).encode("utf-8")

        request = urllib.request.Request(
            self.url_for(path),
            data=body,
            method=method,
            headers=request_headers,
        )
        try:
            with self.opener.open(request, timeout=timeout or self.timeout) as response:
                return Response(
                    status=response.status,
                    headers=dict(response.headers.items()),
                    text=response.read().decode("utf-8", errors="replace"),
                )
        except urllib.error.HTTPError as exc:
            return Response(
                status=exc.code,
                headers=dict(exc.headers.items()),
                text=exc.read().decode("utf-8", errors="replace"),
                error=str(exc),
            )
        except Exception as exc:
            return Response(status=None, headers={}, text="", error=str(exc))

    @staticmethod
    def parse_body(response: Response) -> Any:
        if "json" not in response.content_type.lower():
            return response.text
        try:
            return json.loads(response.text or "null")
        except json.JSONDecodeError:
            return response.text

    def require_ok(self, response: Response, action: str) -> Response:
        if response.ok:
            return response
        detail = response.error or response.text[:TEXT_LIMIT] or "no response body"
        raise ZoteroError(
            f"{action} failed: status={response.status}; detail={detail}"
        )

    def api_response(self, path: str, **kwargs: Any) -> Response:
        api_path = path if path.startswith("/api") else "/api" + path
        return self.require_ok(self.request(api_path, **kwargs), f"{kwargs.get('method', 'GET')} {api_path}")

    def api_json(self, path: str, **kwargs: Any) -> Any:
        return self.parse_body(self.api_response(path, **kwargs))

    def connector_response(self, path: str, **kwargs: Any) -> Response:
        connector_path = path if path.startswith("/connector") else "/connector" + path
        return self.require_ok(
            self.request(connector_path, **kwargs),
            f"{kwargs.get('method', 'GET')} {connector_path}",
        )

    def connector_json(self, path: str, **kwargs: Any) -> Any:
        return self.parse_body(self.connector_response(path, **kwargs))

    def paged_api(self, path: str, params: dict[str, Any] | None = None) -> list[dict[str, Any]]:
        """Read a list route until Zotero's pagination is exhausted."""
        base_params = dict(params or {})
        start = int(base_params.pop("start", 0) or 0)
        limit = int(base_params.pop("limit", API_PAGE_LIMIT) or API_PAGE_LIMIT)
        limit = max(1, min(limit, API_PAGE_LIMIT))
        rows: list[dict[str, Any]] = []

        while True:
            current = dict(base_params)
            current.update({"limit": limit, "start": start})
            separator = "&" if "?" in path else "?"
            response = self.api_response(path + separator + query(current))
            payload = self.parse_body(response)
            if not isinstance(payload, list):
                raise ZoteroError(f"Expected a list from {path}, got {type(payload).__name__}")
            rows.extend(row for row in payload if isinstance(row, dict))

            total = None
            for key, value in response.headers.items():
                if key.lower() == "total-results":
                    try:
                        total = int(value)
                    except ValueError:
                        total = None
                    break
            start += len(payload)
            if not payload or len(payload) < limit or (total is not None and start >= total):
                break
        return rows

    def status(self) -> dict[str, Any]:
        root = self.request("/api/", timeout=2)
        connector = self.request("/connector/ping", timeout=2)
        profile = profile_dir()
        prefs = prefs_file()
        return {
            "base_url": self.base_url,
            "profile": str(profile) if profile else None,
            "prefs_file": str(prefs) if prefs else None,
            "local_api_enabled_pref": read_local_api_pref(),
            "api_running": root.ok,
            "api_status": root.status,
            "api_error": root.error,
            "zotero_version": header(root.headers, "X-Zotero-Version")
            or header(connector.headers, "X-Zotero-Version"),
            "api_version": header(root.headers, "Zotero-API-Version"),
            "schema_version": header(root.headers, "Zotero-Schema-Version"),
            "connector_running": connector.ok,
            "connector_status": connector.status,
            "connector_error": connector.error,
        }

    def probe(self) -> list[dict[str, Any]]:
        endpoints = [
            ("root", "/api/"),
            ("schema", "/api/schema"),
            ("itemTypes", "/api/itemTypes"),
            ("itemFields", "/api/itemFields"),
            ("creatorFields", "/api/creatorFields"),
            ("collections", f"{LOCAL_USER}/collections"),
            ("topCollections", f"{LOCAL_USER}/collections/top"),
            ("topItems", f"{LOCAL_USER}/items/top"),
            ("tags", f"{LOCAL_USER}/tags"),
            ("searches", f"{LOCAL_USER}/searches"),
            ("groups", f"{LOCAL_USER}/groups"),
            ("fulltextVersions", f"{LOCAL_USER}/fulltext?since=0"),
            ("connectorPing", "/connector/ping"),
        ]
        rows: list[dict[str, Any]] = []
        for label, path in endpoints:
            response = self.request(path)
            parsed = self.parse_body(response)
            if isinstance(parsed, list):
                summary: Any = {"type": "array", "len": len(parsed)}
            elif isinstance(parsed, dict):
                summary = {"type": "object", "keys": list(parsed)[:8]}
            else:
                summary = str(parsed)[:160]
            rows.append(
                {
                    "label": label,
                    "path": path,
                    "status": response.status,
                    "contentType": response.content_type,
                    "total": header(response.headers, "Total-Results"),
                    "summary": summary,
                    "error": response.error,
                }
            )
        return rows

    def collections(self, top_only: bool = False) -> list[dict[str, Any]]:
        route = f"{LOCAL_USER}/collections/top" if top_only else f"{LOCAL_USER}/collections"
        return [summarize_collection(row) for row in self.paged_api(route)]

    def items(self, include_children: bool = False) -> list[dict[str, Any]]:
        route = f"{LOCAL_USER}/items" if include_children else f"{LOCAL_USER}/items/top"
        rows = self.paged_api(route, {"sort": "title", "direction": "asc"})
        return [summarize_item(row) for row in rows]

    def collection_items(
        self,
        collection_key: str,
        *,
        top_only: bool = True,
        sort: str = "dateAdded",
        direction: str = "desc",
        with_pdf: bool = False,
    ) -> list[dict[str, Any]]:
        suffix = "/items/top" if top_only else "/items"
        route = f"/api/users/0/collections/{quote_key(collection_key)}{suffix}"
        rows = self.paged_api(route, {"sort": sort, "direction": direction})
        result: list[dict[str, Any]] = []
        for row in rows:
            summary = summarize_item(row)
            if with_pdf:
                attachments = self.children(summary["key"])
                pdfs = pdf_attachments(attachments)
                summary["attachments"] = attachments
                summary["pdfAttachments"] = pdfs
                summary["hasPdf"] = bool(pdfs)
                if not pdfs:
                    continue
            result.append(summary)
        return result

    def get_item(self, item_key: str) -> dict[str, Any]:
        return self.api_json(f"{LOCAL_USER}/items/{quote_key(item_key)}")

    def children(self, item_key: str) -> list[dict[str, Any]]:
        rows = self.api_json(f"{LOCAL_USER}/items/{quote_key(item_key)}/children")
        if not isinstance(rows, list):
            raise ZoteroError(f"Expected child items for {item_key}")
        result: list[dict[str, Any]] = []
        for row in rows:
            if not isinstance(row, dict):
                continue
            data = item_data(row)
            result.append(
                {
                    **summarize_item(row),
                    "contentType": data.get("contentType"),
                    "linkMode": data.get("linkMode"),
                    "filename": data.get("filename"),
                    "path": data.get("path"),
                }
            )
        return result

    def search(self, text: str, with_bibtex_keys: bool = False) -> list[dict[str, Any]]:
        rows = self.paged_api(f"{LOCAL_USER}/items/top", {"q": text})
        result = [summarize_item(row) for row in rows]
        if with_bibtex_keys:
            for item in result:
                bibtex = self.export_bibtex(item_key=item.get("key"))
                keys = extract_bibtex_keys(bibtex)
                item["bibtexKey"] = keys[0] if keys else None
        return result

    def tags(self) -> list[dict[str, Any]]:
        rows = self.paged_api(f"{LOCAL_USER}/tags")
        return [summarize_tag(row) for row in rows]

    def groups(self) -> list[dict[str, Any]]:
        rows = self.paged_api(f"{LOCAL_USER}/groups")
        return [summarize_group(row) for row in rows]

    def fulltext(self, attachment_key: str) -> dict[str, Any]:
        payload = self.api_json(f"{LOCAL_USER}/items/{quote_key(attachment_key)}/fulltext")
        if isinstance(payload, dict):
            return payload
        return {"content": str(payload), "indexedPages": None, "totalPages": None}

    def file_url(self, attachment_key: str) -> str:
        payload = self.api_json(
            f"{LOCAL_USER}/items/{quote_key(attachment_key)}/file/view/url"
        )
        return str(payload)

    def export_bibtex(
        self, item_key: str | None = None, *, include_children: bool = False
    ) -> str:
        if item_key:
            params = query({"itemKey": item_key, "format": "bibtex", "limit": API_PAGE_LIMIT})
            return self.api_response(f"{LOCAL_USER}/items?{params}").text

        endpoint = "items" if include_children else "items/top"
        start = 0
        chunks: list[str] = []
        while True:
            params = query(
                {
                    "format": "bibtex",
                    "sort": "title",
                    "direction": "asc",
                    "limit": API_PAGE_LIMIT,
                    "start": start,
                }
            )
            response = self.api_response(f"{LOCAL_USER}/{endpoint}?{params}")
            if response.text.strip():
                chunks.append(response.text.strip())
            total = header(response.headers, "Total-Results")
            start += API_PAGE_LIMIT
            if total is not None and total.isdigit() and start >= int(total):
                break
            if total is None and count_bibtex_entries(response.text) < API_PAGE_LIMIT:
                break
        text = "\n\n".join(chunks)
        return text + "\n" if text else ""

    def citations(self, style: str = "apa") -> list[dict[str, Any]]:
        rows = self.paged_api(
            f"{LOCAL_USER}/items/top",
            {"include": "data,citation", "style": style},
        )
        result: list[dict[str, Any]] = []
        for row in rows:
            item = summarize_item(row)
            item["citation"] = row.get("citation")
            result.append(item)
        return result

    def selected_target(self) -> Any:
        return self.connector_json(
            "/getSelectedCollection", method="POST", data={}
        )

    def import_records(self, text: str, *, kind: str, session: str | None = None) -> Any:
        if kind.lower() not in {"bibtex", "ris"}:
            raise ZoteroError("kind must be BibTeX or RIS")
        session = session or f"workbuddy-zotero-{uuid.uuid4().hex}"
        response = self.connector_response(
            "/import?" + query({"session": session}),
            method="POST",
            data=text,
            headers={"Content-Type": "text/plain"},
        )
        return {
            "status": response.status,
            "session": session,
            "response": self.parse_body(response),
        }

    def set_local_api(self, enabled: bool, *, restart: bool = False) -> dict[str, Any]:
        backup = set_local_api_pref(enabled)
        restarted = restart_zotero(wait_for_api=enabled) if restart else False
        return {
            "enabled": enabled,
            "backup": str(backup),
            "restarted": restarted,
            "status": self.status(),
        }


def header(headers: dict[str, str], name: str) -> str | None:
    for key, value in headers.items():
        if key.lower() == name.lower():
            return value
    return None


def extract_bibtex_keys(text: str) -> list[str]:
    return re.findall(r"@\w+\s*\{\s*([^,\s]+)", text)


def count_bibtex_entries(text: str) -> int:
    return len(extract_bibtex_keys(text))


def zotero_roots() -> list[Path]:
    configured = os.environ.get("ZOTERO_PROFILE_ROOT")
    if configured:
        return [Path(configured).expanduser()]

    home = Path.home()
    system = platform.system()
    roots: list[Path] = []
    if system == "Windows":
        appdata = os.environ.get("APPDATA")
        if appdata:
            roots.extend([Path(appdata) / "Zotero/Zotero", Path(appdata) / "Zotero"])
    elif system == "Darwin":
        roots.append(home / "Library/Application Support/Zotero")
    else:
        roots.extend(
            [
                home / ".zotero/zotero",
                home / ".var/app/org.zotero.Zotero/data/zotero",
            ]
        )
    return list(dict.fromkeys(roots))


def profiles_ini_path() -> Path | None:
    for root in zotero_roots():
        candidate = root / "profiles.ini"
        if candidate.exists():
            return candidate
    return None


def profile_dir() -> Path | None:
    ini = profiles_ini_path()
    if ini is None:
        return None

    parser = configparser.RawConfigParser()
    parser.read(ini, encoding="utf-8")
    root = ini.parent
    candidates: list[tuple[int, Path]] = []
    for section in parser.sections():
        if not section.lower().startswith("profile") or not parser.has_option(section, "Path"):
            continue
        raw_path = parser.get(section, "Path")
        path = (
            root / raw_path
            if parser.get(section, "IsRelative", fallback="1") == "1"
            else Path(raw_path)
        )
        score = 10 if parser.get(section, "Default", fallback="0") == "1" else 0
        if (path / "prefs.js").exists():
            score += 5
        candidates.append((score, path))
    if candidates:
        return max(candidates, key=lambda item: item[0])[1]
    profiles = sorted((root / "Profiles").glob("*.default*"))
    return profiles[0] if profiles else None


def prefs_file() -> Path | None:
    profile = profile_dir()
    if profile is None:
        return None
    candidate = profile / "prefs.js"
    return candidate if candidate.exists() else None


LOCAL_API_PREF = "extensions.zotero.httpServer.localAPI.enabled"


def read_local_api_pref() -> bool | None:
    prefs = prefs_file()
    if prefs is None:
        return None
    pattern = re.compile(
        r'user_pref\("' + re.escape(LOCAL_API_PREF) + r'",\s*(true|false)\s*\);'
    )
    match = pattern.search(prefs.read_text(encoding="utf-8", errors="replace"))
    return None if match is None else match.group(1) == "true"


def set_local_api_pref(enabled: bool) -> Path:
    prefs = prefs_file()
    if prefs is None:
        raise ZoteroError("Could not find Zotero prefs.js. Start Zotero once, then retry.")

    backup = prefs.with_suffix(prefs.suffix + f".workbuddy-backup-{int(time.time())}")
    shutil.copy2(prefs, backup)
    text = prefs.read_text(encoding="utf-8", errors="replace")
    new_line = f'user_pref("{LOCAL_API_PREF}", {str(enabled).lower()});'
    pattern = re.compile(
        r'user_pref\("' + re.escape(LOCAL_API_PREF) + r'",\s*(true|false)\s*\);'
    )
    if pattern.search(text):
        text = pattern.sub(new_line, text, count=1)
    else:
        text = text.rstrip("\n") + "\n" + new_line + "\n"
    prefs.write_text(text, encoding="utf-8")
    return backup


def restart_zotero(wait_for_api: bool = True) -> bool:
    """Restart Zotero only when explicitly requested by the caller."""
    try:
        if platform.system() == "Windows":
            subprocess.run(
                ["taskkill", "/IM", "zotero.exe", "/F"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                check=False,
            )
            time.sleep(1)
            subprocess.Popen(
                ["zotero.exe"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
            )
        elif platform.system() == "Darwin":
            subprocess.run(
                ["osascript", "-e", 'tell application "Zotero" to quit'],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                check=False,
            )
            time.sleep(1)
            subprocess.run(["open", "-a", "Zotero"], check=False)
        else:
            subprocess.run(
                ["pkill", "-f", "zotero"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                check=False,
            )
            time.sleep(1)
            subprocess.Popen(["zotero"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        return False

    if not wait_for_api:
        return True
    for _ in range(30):
        if ZoteroClient().request("/api/", timeout=1).ok:
            return True
        time.sleep(0.5)
    return False


class QueueLock:
    """Cross-process lock using an atomic directory create on Windows and POSIX."""

    def __init__(self, queue_file: str | Path, timeout: float = 30.0, stale_after: float = 86400.0):
        self.queue_file = Path(queue_file)
        self.lock_dir = Path(str(self.queue_file) + ".lock")
        self.timeout = timeout
        self.stale_after = stale_after
        self.acquired = False

    def __enter__(self) -> "QueueLock":
        self.lock_dir.parent.mkdir(parents=True, exist_ok=True)
        deadline = time.monotonic() + self.timeout
        while True:
            try:
                self.lock_dir.mkdir()
                (self.lock_dir / "owner.json").write_text(
                    json.dumps({"pid": os.getpid(), "createdAt": now_iso()}),
                    encoding="utf-8",
                )
                self.acquired = True
                return self
            except FileExistsError:
                try:
                    age = time.time() - self.lock_dir.stat().st_mtime
                    if age > self.stale_after:
                        shutil.rmtree(self.lock_dir, ignore_errors=True)
                        continue
                except FileNotFoundError:
                    continue
                if time.monotonic() >= deadline:
                    raise ZoteroError(f"Queue is locked by another worker: {self.queue_file}")
                time.sleep(0.1)

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        if self.acquired:
            shutil.rmtree(self.lock_dir, ignore_errors=True)
            self.acquired = False


def read_json(path: str | Path, default: Any = None) -> Any:
    file_path = Path(path)
    if not file_path.exists():
        return default
    try:
        return json.loads(file_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ZoteroError(f"Invalid JSON file: {file_path}: {exc}") from exc


def write_json_atomic(path: str | Path, value: Any) -> None:
    file_path = Path(path).expanduser().resolve()
    file_path.parent.mkdir(parents=True, exist_ok=True)
    fd, raw_temp = tempfile.mkstemp(
        prefix=file_path.name + ".", suffix=".tmp", dir=str(file_path.parent)
    )
    temp_path = Path(raw_temp)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
            json.dump(value, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_path, file_path)
    finally:
        if temp_path.exists():
            temp_path.unlink()


def write_text_atomic(path: str | Path, text: str) -> None:
    file_path = Path(path).expanduser().resolve()
    file_path.parent.mkdir(parents=True, exist_ok=True)
    fd, raw_temp = tempfile.mkstemp(
        prefix=file_path.name + ".", suffix=".tmp", dir=str(file_path.parent)
    )
    temp_path = Path(raw_temp)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_path, file_path)
    finally:
        if temp_path.exists():
            temp_path.unlink()


def pdf_attachment(children: list[dict[str, Any]]) -> dict[str, Any] | None:
    attachments = pdf_attachments(children)
    return attachments[0] if attachments else None


def pdf_attachments(children: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [
        child
        for child in children
        if child.get("contentType") == "application/pdf"
        or str(child.get("title") or "").lower().endswith(".pdf")
    ]


def build_queue(
    client: ZoteroClient,
    *,
    collection_key: str,
    collection_name: str | None = None,
    require_pdf: bool = True,
    sort: str = "dateAdded",
    direction: str = "desc",
    queue_file: str | Path,
    rebuild: bool = False,
) -> dict[str, Any]:
    queue_path = Path(queue_file).expanduser().resolve()
    with QueueLock(queue_path):
        old = read_json(queue_path, {}) if queue_path.exists() else {}
        if old and not rebuild:
            return old

        source = client.collection_items(
            collection_key,
            top_only=True,
            sort=sort,
            direction=direction,
            # Fetch all top-level records first so the no-PDF report is real.
            with_pdf=False,
        )
        excluded: list[dict[str, Any]] = []
        eligible: list[dict[str, Any]] = []
        for item in source:
            item_key = str(item.get("key") or "")
            if not require_pdf:
                eligible.append(item)
                continue

            attachments = client.children(item_key)
            pdfs = pdf_attachments(attachments)
            if not pdfs:
                excluded.append(
                    {
                        "itemKey": item_key,
                        "title": item.get("title"),
                        "creators": item.get("creators", []),
                        "dateAdded": item.get("dateAdded"),
                        "reason": "no PDF child attachment",
                    }
                )
                continue

            eligible.append(
                {
                    **item,
                    "attachments": attachments,
                    "pdfAttachments": pdfs,
                    "hasPdf": True,
                }
            )

        old_by_key = {
            str(item.get("itemKey")): item
            for item in (old.get("items", []) if isinstance(old, dict) else [])
            if item.get("itemKey")
        }
        items: list[dict[str, Any]] = []
        for index, item in enumerate(eligible, start=1):
            attachment = pdf_attachment(item.get("pdfAttachments", []))
            item_key = str(item.get("key"))
            previous = old_by_key.get(item_key, {})
            queue_item = {
                "index": index,
                "itemKey": item_key,
                "attachmentKey": attachment.get("key") if attachment else None,
                "attachmentTitle": attachment.get("title") if attachment else None,
                "attachmentContentType": attachment.get("contentType") if attachment else None,
                "itemType": item.get("itemType"),
                "title": item.get("title"),
                "publicationTitle": item.get("publicationTitle"),
                "date": item.get("date"),
                "year": item.get("year"),
                "dateAdded": item.get("dateAdded"),
                "DOI": item.get("DOI"),
                "creators": item.get("creators", []),
                "status": previous.get("status", "pending"),
                "attempts": previous.get("attempts", 0),
                "outputFile": previous.get("outputFile"),
                "startedAt": previous.get("startedAt"),
                "finishedAt": previous.get("finishedAt"),
                "lastError": previous.get("lastError"),
                "runId": previous.get("runId"),
            }
            items.append(queue_item)

        queue = {
            "schemaVersion": 1,
            "collectionKey": collection_key,
            "collectionName": collection_name or collection_key,
            "orderBy": f"{sort}_{direction}",
            "createdAt": old.get("createdAt") if isinstance(old, dict) else None,
            "updatedAt": now_iso(),
            "total": len(items),
            "excludedNoPdfCount": len(excluded),
            "excludedNoPdf": excluded,
            "items": items,
        }
        if not queue["createdAt"]:
            queue["createdAt"] = now_iso()
        write_json_atomic(queue_path, queue)
        return queue


def queue_status(queue_file: str | Path) -> dict[str, Any]:
    queue_path = Path(queue_file).expanduser().resolve()
    queue = read_json(queue_path)
    if not isinstance(queue, dict):
        raise ZoteroError(f"Queue file is not an object: {queue_path}")
    items = queue.get("items", [])
    if not isinstance(items, list):
        raise ZoteroError(f"Queue items is not a list: {queue_path}")
    counts = {"pending": 0, "in_progress": 0, "done": 0, "failed": 0, "other": 0}
    for item in items:
        status = item.get("status") if isinstance(item, dict) else None
        if status in counts:
            counts[status] += 1
        else:
            counts["other"] += 1
    finished = counts["pending"] == 0 and counts["in_progress"] == 0
    completed = finished and counts["failed"] == 0 and counts["other"] == 0
    return {
        "queueFile": str(queue_path),
        "collectionKey": queue.get("collectionKey"),
        "collectionName": queue.get("collectionName"),
        "orderBy": queue.get("orderBy"),
        "total": queue.get("total", len(items)),
        "counts": counts,
        "finished": finished,
        "completed": completed,
        "needsReview": counts["failed"] > 0 or counts["other"] > 0,
        "updatedAt": queue.get("updatedAt"),
    }


def prepare_next(queue_file: str | Path, worker_id: str | None = None) -> dict[str, Any] | None:
    queue_path = Path(queue_file).expanduser().resolve()
    with QueueLock(queue_path):
        queue = read_json(queue_path)
        if not isinstance(queue, dict):
            raise ZoteroError(f"Queue file is not an object: {queue_path}")
        items = queue.get("items", [])
        for item in items:
            if isinstance(item, dict) and item.get("status") == "pending":
                item["status"] = "in_progress"
                item["attempts"] = int(item.get("attempts") or 0) + 1
                item["startedAt"] = now_iso()
                item["runId"] = f"{local_timestamp()}-{uuid.uuid4().hex[:8]}"
                item["workerId"] = worker_id or f"pid-{os.getpid()}"
                item["lastError"] = None
                queue["updatedAt"] = now_iso()
                write_json_atomic(queue_path, queue)
                return dict(item)
        return None


def update_queue_item(
    queue_file: str | Path,
    *,
    item_key: str,
    status: str,
    output_file: str | None = None,
    error: str | None = None,
) -> dict[str, Any]:
    if status not in {"pending", "in_progress", "done", "failed"}:
        raise ZoteroError(f"Unsupported queue status: {status}")
    queue_path = Path(queue_file).expanduser().resolve()
    with QueueLock(queue_path):
        queue = read_json(queue_path)
        if not isinstance(queue, dict):
            raise ZoteroError(f"Queue file is not an object: {queue_path}")
        found: dict[str, Any] | None = None
        for item in queue.get("items", []):
            if isinstance(item, dict) and str(item.get("itemKey")) == str(item_key):
                item["status"] = status
                if output_file is not None:
                    item["outputFile"] = str(Path(output_file).expanduser().resolve())
                if status == "done":
                    item["finishedAt"] = now_iso()
                    item["lastError"] = None
                elif status == "failed":
                    item["lastError"] = error or "unspecified failure"
                elif error is not None:
                    item["lastError"] = error
                found = dict(item)
                break
        if found is None:
            raise ZoteroError(f"Item not found in queue: {item_key}")
        queue["updatedAt"] = now_iso()
        write_json_atomic(queue_path, queue)
        status_payload = queue_status(queue_path)
        if status_payload["completed"]:
            flag = queue_path.with_name(queue_path.name + ".completed.flag")
            write_text_atomic(flag, f"completedAt={now_iso()}\n")
        return {"updated": found, "status": status_payload}


def style_file_path(explicit: str | None = None) -> Path | None:
    configured = explicit or os.environ.get("ZOTERO_STYLE_FILE")
    if configured:
        return Path(configured).expanduser()
    root = os.environ.get("ZOTERO_STYLE_ROOT")
    if root:
        candidate = Path(root).expanduser() / "zoterostyle.json"
        return candidate
    return None


def journal_style_label(journal_name: str, style_path: str | None = None) -> dict[str, Any]:
    path = style_file_path(style_path)
    if path is None:
        return {
            "found": False,
            "reason": "ZOTERO_STYLE_FILE or ZOTERO_STYLE_ROOT is not configured",
        }
    if not path.exists():
        return {"found": False, "path": str(path), "reason": "style file not found"}
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return {"found": False, "path": str(path), "reason": str(exc)}

    target = normalize_name(journal_name)
    matches: list[dict[str, Any]] = []

    def fields_from_node(node: dict[str, Any]) -> dict[str, Any]:
        fields = {key: node.get(key) for key in STYLE_FIELDS if key in node}
        rank = node.get("rank")
        if isinstance(rank, dict):
            fields.update({key: rank.get(key) for key in STYLE_FIELDS if key in rank})
        return fields

    def visit(node: Any, source_key: str | None = None) -> None:
        if isinstance(node, dict):
            names: list[str] = []
            for key in (
                "journal",
                "journalName",
                "publicationTitle",
                "title",
                "name",
                "fullName",
            ):
                value = node.get(key)
                if isinstance(value, str):
                    names.append(value)
            if source_key:
                names.append(source_key)
            if any(normalize_name(name) == target for name in names):
                fields = fields_from_node(node)
                if fields:
                    matches.append({"matchedNames": names, "fields": fields})
            for key, value in node.items():
                visit(value, str(key))
        elif isinstance(node, list):
            for value in node:
                visit(value, source_key)

    visit(payload)
    return {
        "found": bool(matches),
        "path": str(path),
        "journal": journal_name,
        "matches": matches,
        "fields": matches[0]["fields"] if matches else {},
    }

# WorkBuddy 首次迁移提示词

请把当前目录中的 `server.py` 作为一个标准 MCP stdio 服务使用，并通过它连接本机已经运行的 Zotero Desktop。

## 首次检查

1. 先调用 `zotero_status`，确认 Local API 和 Connector 可用；如果不可用，只报告具体阻断原因，不要擅自修改 Zotero 设置或重启 Zotero。
2. 调用 `zotero_collections`，读取目标电脑上的真实一级和二级集合名称及 key。不要沿用另一台电脑的 collection key。
3. 根据用户指定的集合路径，确认只使用该路径对应的顶层文献。不要把子集合中的记录、回收站记录或整个库混入队列。
4. 调用 `zotero_collection_items` 检查数量和 `dateAdded` 顺序；需要精读时只保留有 PDF 子附件的顶层文献。
5. 使用 `zotero_journal_style` 查询期刊分区。Style 文件路径从环境变量 `ZOTERO_STYLE_FILE` 或 `ZOTERO_STYLE_ROOT` 获取；查不到时如实写“未找到”，不要猜测。

## 队列和精读

1. 在目标工作目录创建独立的 `reading-queue.json`，调用 `zotero_build_reading_queue`，传入目标 collection key、队列路径、`requirePdf=true`、`sort=dateAdded`、`direction=desc`。
2. 后续每次开始前调用 `zotero_prepare_next`。它会原子地领取一篇 `pending` 文献；不要自行按标题或已有笔记判断是否重复。
3. 使用返回的 `itemKey` 调用 `zotero_get_item` 和 `zotero_get_children`，使用返回的 PDF attachment key 调用 `zotero_get_fulltext`。全文、摘要、元数据和期刊标签之外不要编造内容。
4. 按用户提供的 Markdown 模板和填写说明生成笔记，并把文件写入用户指定的 `notes/` 目录。笔记正文用中文，专业术语首次出现保留英文原文；日期使用当前实际日期。
5. 写完后先确认 Markdown 文件存在且内容完整，再调用 `zotero_mark_done`，传入队列路径、item key 和输出文件绝对路径。
6. 发生可恢复错误时调用 `zotero_mark_failed` 并保留简短错误；修复问题后才调用 `zotero_reset_pending` 重试。不要把失败直接标记为完成。
7. 通过 `zotero_queue_status` 判断是否还有 `pending` 或 `in_progress`。只有 `completed=true` 才能宣称全部完成；如果 `needsReview=true`，先报告失败清单，不要把 `finished=true` 当作全部成功。

## 约束

- 不要根据 Zotero 中是否已有普通笔记跳过记录；队列状态才是重复领取的唯一依据。
- 不要在每次运行时传 `rebuild=true`；只有集合内容需要重新扫描时才重建，重建会按 item key 保留已有状态。
- 不要调用 `zotero_import_records` 或 `zotero_set_local_api`，除非用户明确要求，并且调用时显式传 `confirm=true`。
- 不要把本机的 Zotero 数据库、PDF、API key、账号 token 或绝对路径复制到目标电脑。
- 只使用普通 Markdown 和纯文本表格，不添加彩色标记、HTML 颜色、背景色或装饰性高亮。

# WorkBuddy Zotero MCP

这是一个可迁移的 Zotero Desktop 本地连接包。它用 Python 标准库实现
newline-delimited JSON-RPC MCP stdio 服务，不依赖 Codex Desktop，也不依赖
Computer Use、截图或鼠标操作。

当前包版本：`0.1.1`。

## 包含内容

- `server.py`：MCP stdio 服务入口
- `zotero_client.py`：Zotero Local API、Connector、全文和队列实现
- `manifest.json`：与平台无关的能力清单示例
- `workbuddy-mcp-config.example.json`：WorkBuddy MCP 配置示例
- `run.ps1`、`run.cmd`：Windows 启动入口
- `requirements.txt`：说明无第三方依赖
- `NOTICE.md`：迁移和许可注意事项
- `WORKBUDDY-MIGRATION-PROMPT.md`：目标电脑首次配置和精读流程提示词
- `WORKBUDDY-ZOTERO-MCP-DEPLOY-PROMPT.md`：可直接交给 WorkBuddy 的完整部署提示词

## 前置条件

1. 安装 Zotero Desktop。
2. 在 Zotero 中启用 Local API，或者先运行：

   ```powershell
   .\run.ps1 -Check
   ```

3. 使用 Python 3.10 或更新版本。
4. 如果要查询期刊分区标签，设置 `ZOTERO_STYLE_FILE`，例如：

   ```text
   F:\documents\Zotero\zoterostyle.json
   ```

本地 API 默认地址为 `http://127.0.0.1:23119`。代码会强制绕过系统代理，
避免本地请求被代理转发。

## WorkBuddy 配置

打开 `workbuddy-mcp-config.example.json`，把其中的路径改为目标电脑的绝对
路径，然后按照 WorkBuddy 当前版本的 MCP 配置格式导入。示例使用：

```json
{
  "mcpServers": {
    "zotero": {
      "command": "py",
      "args": ["-3", "E:\\path\\to\\workbuddy-zotero-mcp\\server.py"]
    }
  }
}
```

如果 WorkBuddy 不识别 `py`，把 `command` 改成 Python 的绝对路径，例如：

```text
C:\Users\YourName\AppData\Local\Programs\Python\Python312\python.exe
```

这个包的 `manifest.json` 是通用说明，不假定 WorkBuddy 的私有 manifest
字段。真正导入时以 WorkBuddy 官方 MCP 配置格式为准。

### 复制到另一台电脑

1. 复制整个 `workbuddy-zotero-mcp` 文件夹，不要只复制 `server.py`。
2. 目标电脑安装 Python 3.10+ 和 Zotero Desktop，并启动 Zotero。
3. 将 `workbuddy-mcp-config.example.json` 中的 `server.py`、Style 文件和其他路径改成目标电脑的绝对路径。
4. 在 WorkBuddy 的 MCP 设置中加入 `mcpServers.zotero` 配置，或直接使用 `run.cmd` 作为 stdio 启动入口。
5. 先运行 `run.ps1 -Check`，确认 Local API 和 Connector 都是可用状态，再让 WorkBuddy 调用其他工具。

目标电脑的 Zotero 集合 key、文献库内容和 Style 文件可能不同；迁移时不要复制本机的
Zotero 数据库、PDF 或队列状态，先用 `zotero_collections` 找到目标集合，再在目标目录
新建队列。

## MCP 工具

基础访问工具：

```text
zotero_status
zotero_probe
zotero_collections
zotero_inventory
zotero_collection_items
zotero_search
zotero_get_item
zotero_get_children
zotero_get_fulltext
zotero_get_file_url
zotero_tags
zotero_groups
```

引用和 Connector 工具：

```text
zotero_export_bibtex
zotero_citations
zotero_selected_target
zotero_import_records
zotero_set_local_api
```

精读队列工具：

```text
zotero_build_reading_queue
zotero_queue_status
zotero_prepare_next
zotero_mark_done
zotero_mark_failed
zotero_reset_pending
zotero_journal_style
```

## 你的精读流程如何接入

```text
WorkBuddy
  -> zotero_collection_items(collectionKey, withPdf=true)
  -> zotero_build_reading_queue
  -> zotero_prepare_next
  -> zotero_get_item / zotero_get_children / zotero_get_fulltext
  -> WorkBuddy 按模板生成 Markdown
  -> zotero_mark_done
```

队列默认按 `dateAdded_desc` 排序。`zotero_prepare_next` 使用原子队列更新和
锁目录，同一个队列可以被多个 worker 安全地竞争领取，但每次只会领取一篇
`pending` 文献。

`zotero_build_reading_queue` 在 `requirePdf=true` 时会扫描集合中的全部顶层文献，
把没有 PDF 子附件的记录写入 `excludedNoPdf`，而不是静默丢弃。使用 `rebuild=true`
刷新集合时，会按 Zotero item key 保留原队列的状态和尝试次数；不要在每次 worker
运行时重建队列，否则会增加无谓的 API 扫描。

队列不会根据 Zotero 中是否已有普通笔记来跳过记录。是否已经完成由队列的
`pending/in_progress/done/failed` 状态决定；因此可以按需要重新精读已有笔记的文献，
同时仍能避免同一队列被重复领取。`finished=true` 表示没有活动项，
`completed=true` 才表示全部条目成功，`needsReview=true` 表示存在失败或异常状态。

`zotero_get_fulltext` 默认最多返回 250000 个字符，可以通过 `maxChars` 调整。
附件全文和 `file-url` 可能包含论文文本或本地文件路径，只有在用户明确要求
时才应调用。

## 写入边界

- Local API 读取不需要 Zotero Web API key。
- 本地 API 读取接口按 Zotero 文档是只读的。
- `zotero_import_records` 必须传 `confirm=true`，否则拒绝修改 Zotero。
- `zotero_set_local_api` 必须传 `confirm=true`；`restart=true` 会重启 Zotero，
  仅应在用户明确要求时使用。
- 队列状态写入的是本地 JSON，不会自动修改 Zotero 文献库。

当前包没有把 Markdown 自动创建成 Zotero 子笔记，因为不同 Zotero Connector
版本对 `saveItems` 的 note payload 处理需要在目标环境单独验证。可以先让
WorkBuddy 生成文件，再使用现有的笔记导入脚本，或者下一阶段增加经过测试的
note importer。

`WORKBUDDY-MIGRATION-PROMPT.md` 提供了一份可直接粘贴给 WorkBuddy 的首次配置和
精读流程提示词。它要求先确认目标集合和 PDF 数量，再创建队列，不会假设本机的
collection key。

## 手动检查

```powershell
Set-Location 'C:\path\to\workbuddy-zotero-mcp'
.\run.ps1 -Check
```

协议测试可以运行：

```powershell
py -3 -m unittest discover -s tests -v
```

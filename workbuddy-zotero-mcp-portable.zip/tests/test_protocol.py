import json
import pathlib
import sys
import unittest


PACKAGE_ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PACKAGE_ROOT))

from server import MCPServer, TOOLS  # noqa: E402


class ProtocolTests(unittest.TestCase):
    def setUp(self):
        self.server = MCPServer()

    def test_initialize(self):
        response = self.server.handle(
            {"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {}}
        )
        self.assertEqual(response["id"], 1)
        self.assertIn("protocolVersion", response["result"])
        self.assertEqual(response["result"]["serverInfo"]["name"], "workbuddy-zotero")

    def test_tools_list_has_core_and_queue_tools(self):
        response = self.server.handle(
            {"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}}
        )
        names = {tool["name"] for tool in response["result"]["tools"]}
        self.assertEqual(names, {tool["name"] for tool in TOOLS})
        self.assertIn("zotero_get_fulltext", names)
        self.assertIn("zotero_prepare_next", names)

    def test_unknown_tool_is_protocol_error(self):
        response = self.server.handle(
            {
                "jsonrpc": "2.0",
                "id": 3,
                "method": "tools/call",
                "params": {"name": "missing", "arguments": {}},
            }
        )
        self.assertEqual(response["error"]["code"], -32602)

    def test_notification_has_no_response(self):
        self.assertIsNone(
            self.server.handle(
                {
                    "jsonrpc": "2.0",
                    "method": "notifications/initialized",
                }
            )
        )

    def test_import_requires_explicit_confirmation(self):
        response = self.server.handle(
            {
                "jsonrpc": "2.0",
                "id": 4,
                "method": "tools/call",
                "params": {
                    "name": "zotero_import_records",
                    "arguments": {
                        "kind": "BibTeX",
                        "text": "@article{example, title={Example}}",
                        "confirm": False,
                    },
                },
            }
        )
        self.assertTrue(response["result"]["isError"])
        self.assertIn("confirm=true", response["result"]["content"][0]["text"])

    def test_tool_schemas_reject_unknown_arguments(self):
        for registered_tool in TOOLS:
            self.assertFalse(registered_tool["inputSchema"]["additionalProperties"])

    def test_bibtex_tool_reports_entry_count(self):
        class ExportClient:
            def export_bibtex(self, *, item_key=None, include_children=False):
                return "@article{one, title={One}}\n@book{two, title={Two}}\n"

        server = MCPServer(ExportClient())
        response = server.handle(
            {
                "jsonrpc": "2.0",
                "id": 5,
                "method": "tools/call",
                "params": {"name": "zotero_export_bibtex", "arguments": {}},
            }
        )
        payload = json.loads(response["result"]["content"][0]["text"])
        self.assertEqual(payload["entries"], 2)


if __name__ == "__main__":
    unittest.main()

import json
import pathlib
import sys
import tempfile
import unittest


PACKAGE_ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PACKAGE_ROOT))

from zotero_client import (  # noqa: E402
    build_queue,
    count_bibtex_entries,
    journal_style_label,
    prepare_next,
    update_queue_item,
)


class FakeQueueClient:
    def __init__(self):
        self.records = [
            {
                "key": "WITHPDF",
                "itemType": "journalArticle",
                "title": "Paper with PDF",
                "creators": ["Author A"],
                "year": "2025",
                "date": "2025",
                "dateAdded": "2025-02-01T00:00:00Z",
                "publicationTitle": "Journal A",
                "DOI": "10.1000/example",
            },
            {
                "key": "NOPDF00",
                "itemType": "journalArticle",
                "title": "Paper without PDF",
                "creators": ["Author B"],
                "year": "2024",
                "date": "2024",
                "dateAdded": "2025-01-01T00:00:00Z",
                "publicationTitle": "Journal B",
                "DOI": None,
            },
        ]

    def collection_items(self, collection_key, *, top_only, sort, direction, with_pdf):
        self.collection_call = (collection_key, top_only, sort, direction, with_pdf)
        return list(self.records)

    def children(self, item_key):
        if item_key == "WITHPDF":
            return [
                {
                    "key": "PDFCHILD",
                    "title": "paper.pdf",
                    "contentType": "application/pdf",
                }
            ]
        return []


class ClientTests(unittest.TestCase):
    def test_bibtex_entry_count(self):
        text = "@article{one, title={One}}\n\n@book{two, title={Two}}\n"
        self.assertEqual(count_bibtex_entries(text), 2)

    def test_build_queue_reports_no_pdf_and_preserves_state_on_rebuild(self):
        client = FakeQueueClient()
        with tempfile.TemporaryDirectory() as directory:
            queue_file = pathlib.Path(directory) / "reading-queue.json"
            first = build_queue(
                client,
                collection_key="COLLECTION",
                collection_name="Example",
                queue_file=queue_file,
            )
            self.assertEqual(first["total"], 1)
            self.assertEqual(first["excludedNoPdfCount"], 1)
            self.assertEqual(first["excludedNoPdf"][0]["itemKey"], "NOPDF00")
            claimed = prepare_next(queue_file, "worker-a")
            self.assertEqual(claimed["itemKey"], "WITHPDF")
            update_queue_item(
                queue_file,
                item_key="WITHPDF",
                status="done",
                output_file=str(pathlib.Path(directory) / "note.md"),
            )
            self.assertIsNone(prepare_next(queue_file, "worker-b"))
            done_status = json.loads(queue_file.read_text(encoding="utf-8"))
            self.assertTrue(done_status["items"][0]["status"] == "done")
            rebuilt = build_queue(
                client,
                collection_key="COLLECTION",
                collection_name="Example",
                queue_file=queue_file,
                rebuild=True,
            )
            self.assertEqual(rebuilt["items"][0]["status"], "done")
            self.assertEqual(client.collection_call[-1], False)

    def test_failed_queue_is_finished_but_not_completed(self):
        client = FakeQueueClient()
        with tempfile.TemporaryDirectory() as directory:
            queue_file = pathlib.Path(directory) / "reading-queue.json"
            build_queue(client, collection_key="COLLECTION", queue_file=queue_file)
            claimed = prepare_next(queue_file, "worker-a")
            update_queue_item(
                queue_file,
                item_key=claimed["itemKey"],
                status="failed",
                error="test failure",
            )
            from zotero_client import queue_status

            status = queue_status(queue_file)
            self.assertTrue(status["finished"])
            self.assertFalse(status["completed"])
            self.assertTrue(status["needsReview"])

    def test_journal_style_label_reads_nested_fields(self):
        with tempfile.TemporaryDirectory() as directory:
            style_file = pathlib.Path(directory) / "zoterostyle.json"
            style_file.write_text(
                json.dumps(
                    {
                        "Materials Today Energy": {
                            "rank": {
                                "sciif": "8.6",
                                "sci": "Q1",
                                "sciUp": "材料科学2区",
                                "sciUpSmall": "材料科学：综合2区/能源与燃料3区。",
                                "eii": "EI",
                            }
                        }
                    }
                ),
                encoding="utf-8",
            )
            result = journal_style_label("Materials Today Energy", str(style_file))
            self.assertTrue(result["found"])
            self.assertEqual(result["fields"]["sciif"], "8.6")
            self.assertEqual(result["fields"]["sci"], "Q1")


if __name__ == "__main__":
    unittest.main()
